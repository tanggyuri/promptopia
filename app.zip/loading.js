import React from 'react'

const loading = () => {
  return (
    <div>
      <LoadingSkeleton />
    </div>
  )
}

export default loading