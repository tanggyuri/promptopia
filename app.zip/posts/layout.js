import React from 'react'

const layout = () => {
  return (
    <div>
      hello
    </div>
  )
}

export default layout
