import React from 'react'

const page2 = () => {
  return (
    <div>
      page2
    </div>
  )
}

export default page2
